import 'package:flutter/material.dart';

const brandRed = Color(0xFFE50924);
const pageBg = Color(0xFF080A0D);
const cardBg = Color(0xFF11151A);
const muted = Color(0xFF9AA3AE);

void main() => runApp(const ShoppixApp());

class ShoppixApp extends StatelessWidget {
  const ShoppixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shoppix',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: pageBg,
        colorScheme: const ColorScheme.dark(
          primary: brandRed,
          surface: cardBg,
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const HomeScreen()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.black,
    body: Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const ShoppixMark(size: 92),
        const SizedBox(height: 18),
        RichText(text: const TextSpan(
          style: TextStyle(fontSize: 42, fontWeight: FontWeight.w800, letterSpacing: -1.5),
          children: [
            TextSpan(text: 'Shop', style: TextStyle(color: Colors.white)),
            TextSpan(text: 'pix', style: TextStyle(color: brandRed)),
          ],
        )),
        const SizedBox(height: 8),
        const Text('Discover. Showcase. Shop.', style: TextStyle(color: Colors.white70, fontSize: 14)),
        const SizedBox(height: 130),
        const Text('from', style: TextStyle(color: muted, fontSize: 14)),
        const SizedBox(height: 5),
        const Text('A abhi', style: TextStyle(color: brandRed, fontWeight: FontWeight.bold, fontSize: 25)),
      ]),
    ),
  );
}

class ShoppixMark extends StatelessWidget {
  final double size;
  const ShoppixMark({super.key, this.size = 42});
  @override
  Widget build(BuildContext context) => Container(
    width: size, height: size,
    decoration: BoxDecoration(
      color: brandRed.withOpacity(.10),
      border: Border.all(color: brandRed, width: 2.4),
      borderRadius: BorderRadius.circular(size * .28),
    ),
    child: Center(child: Text('S', style: TextStyle(
      color: brandRed, fontSize: size * .68, fontWeight: FontWeight.w900,
    ))),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  final Set<int> liked = {};

  void notice(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(message), backgroundColor: cardBg,
      behavior: SnackBarBehavior.floating,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: pageBg, elevation: 0,
        titleSpacing: 16,
        title: Row(children: [
          const ShoppixMark(size: 34), const SizedBox(width: 9),
          RichText(text: const TextSpan(style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800),
            children: [TextSpan(text: 'Shop', style: TextStyle(color: Colors.white)),
              TextSpan(text: 'pix', style: TextStyle(color: brandRed))])),
        ]),
        actions: [
          IconButton(onPressed: () => notice('Search will be connected in the next build.'), icon: const Icon(Icons.search, size: 28)),
          IconButton(onPressed: () => notice('Notifications will appear here.'), icon: const Icon(Icons.notifications_none, size: 27)),
        ],
      ),
      body: IndexedStack(index: tab, children: [
        _feed(),
        _placeholder('Explore products', Icons.explore_outlined),
        _placeholder('Create a product post', Icons.add_box_outlined),
        _placeholder('Messages', Icons.chat_bubble_outline),
        _placeholder('Your profile', Icons.person_outline),
      ]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF0D1014),
        indicatorColor: brandRed.withOpacity(.16),
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: brandRed), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore, color: brandRed), label: 'Explore'),
          NavigationDestination(icon: Icon(Icons.add_circle, color: brandRed, size: 32), label: 'Post'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat, color: brandRed), label: 'Messages'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person, color: brandRed), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _feed() => ListView(
    padding: EdgeInsets.zero,
    children: [
      _stories(),
      const Divider(color: Colors.white12, height: 18),
      _sellerHeader('shoppix_official', 'Official marketplace'),
      _productCard(
        index: 0,
        seller: 'ShoeHaven',
        location: 'Lagos, Nigeria',
        title: 'Air Jordan 1 Retro High OG',
        description: 'Classic high-top sneakers. Multiple sizes available.',
        price: '₦285,000',
        icon: Icons.shopping_bag_outlined,
        imageLabel: 'SNEAKERS',
        badge: 'HOT DEAL',
      ),
      const SizedBox(height: 14),
      _sellerHeader('tech_world', 'Abuja, Nigeria'),
      _productCard(
        index: 1,
        seller: 'Tech World',
        location: 'Abuja, Nigeria',
        title: 'Premium smartphone',
        description: 'New arrival. Message seller for colours and availability.',
        price: '₦1,250,000',
        icon: Icons.phone_iphone,
        imageLabel: 'SMARTPHONE',
        badge: 'NEW ARRIVAL',
      ),
      const SizedBox(height: 24),
    ],
  );

  Widget _stories() {
    final stories = [
      ('Your story', Icons.add, true),
      ('nike_store', Icons.sports, false),
      ('luxury_time', Icons.watch, false),
      ('trendz_kloth', Icons.checkroom, false),
      ('tech_world', Icons.phone_iphone, false),
      ('stylehub', Icons.shopping_bag, false),
    ];
    return SizedBox(height: 126, child: ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      scrollDirection: Axis.horizontal,
      itemCount: stories.length,
      separatorBuilder: (_, __) => const SizedBox(width: 12),
      itemBuilder: (context, i) {
        final item = stories[i];
        return SizedBox(width: 76, child: GestureDetector(
          onTap: () => notice(i == 0 ? 'Create a product Story.' : 'Product Story preview.'),
          child: Column(children: [
            Container(
              width: 68, height: 68,
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: brandRed, width: 2.5),
              ),
              child: Container(
                decoration: BoxDecoration(color: const Color(0xFF252B33), shape: BoxShape.circle),
                child: Icon(item.$2, color: i == 0 ? brandRed : Colors.white, size: 30),
              ),
            ),
            const SizedBox(height: 7),
            Text(item.$1, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11.5)),
          ]),
        ));
      },
    ));
  }

  Widget _sellerHeader(String name, String subtitle) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
    child: Row(children: [
      const ShoppixMark(size: 38), const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        Text(subtitle, style: const TextStyle(color: muted, fontSize: 12)),
      ])),
      OutlinedButton(
        onPressed: () => notice('Follow feature coming soon.'),
        style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: brandRed)),
        child: const Text('Follow'),
      ),
      IconButton(onPressed: () => notice('More seller options.'), icon: const Icon(Icons.more_horiz)),
    ]),
  );

  Widget _productCard({
    required int index, required String seller, required String location,
    required String title, required String description, required String price,
    required IconData icon, required String imageLabel, required String badge,
  }) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 12),
    decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(16),
      border: Border.all(color: Colors.white12)),
    clipBehavior: Clip.antiAlias,
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(
        height: 245, width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF343B45), Color(0xFF171B21), Color(0xFF080A0D)]),
        ),
        child: Stack(children: [
          Center(child: Icon(icon, size: 112, color: Colors.white.withOpacity(.82))),
          Positioned(left: 12, top: 12, child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: brandRed, borderRadius: BorderRadius.circular(20)),
            child: Text(badge, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 10)),
          )),
          const Positioned(right: 12, top: 12, child: Icon(Icons.bookmark_border, color: Colors.white)),
          Positioned(bottom: 12, left: 0, right: 0,
            child: Text(imageLabel, textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white.withOpacity(.16), fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: 4))),
        ]),
      ),
      Padding(padding: const EdgeInsets.fromLTRB(14, 13, 14, 14), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(seller, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(location, style: const TextStyle(color: muted, fontSize: 12)),
            ])),
            const Icon(Icons.verified, color: brandRed, size: 18),
          ]),
          const SizedBox(height: 12),
          Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          Text(description, style: const TextStyle(color: muted, fontSize: 13)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: Text(price, style: const TextStyle(color: brandRed, fontSize: 20, fontWeight: FontWeight.w900))),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: brandRed, foregroundColor: Colors.white),
              onPressed: () => notice('Checkout will be connected after the backend is added.'),
              icon: const Icon(Icons.shopping_cart_outlined, size: 18),
              label: const Text('Buy now'),
            ),
          ]),
          const Divider(color: Colors.white12, height: 22),
          Row(children: [
            IconButton(
              onPressed: () => setState(() => liked.contains(index) ? liked.remove(index) : liked.add(index)),
              icon: Icon(liked.contains(index) ? Icons.favorite : Icons.favorite_border,
                color: liked.contains(index) ? brandRed : Colors.white),
            ),
            const Text('Like', style: TextStyle(color: muted, fontSize: 12)),
            const SizedBox(width: 18),
            IconButton(onPressed: () => notice('Comments will be available soon.'), icon: const Icon(Icons.mode_comment_outlined)),
            const SizedBox(width: 18),
            IconButton(onPressed: () => notice('Share product link.'), icon: const Icon(Icons.send_outlined)),
            const Spacer(),
            IconButton(onPressed: () => notice('Product saved.'), icon: const Icon(Icons.bookmark_border)),
          ]),
        ],
      )),
    ]),
  );

  Widget _placeholder(String title, IconData icon) => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 56, color: brandRed),
      const SizedBox(height: 12),
      Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('This screen is part of the next development stage.', style: TextStyle(color: muted)),
    ]),
  );
}
