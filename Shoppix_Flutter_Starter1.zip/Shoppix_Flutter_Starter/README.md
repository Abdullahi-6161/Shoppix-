#80FF00print("Hello Dream Circle!")
name = input("What is your name? ")
print("Welcome " + name + ", you don start coding!")# Shoppix Flutter Starter

This is the first **front-end prototype** for Shoppix: a product-only social-commerce marketplace.

## Included
- Dark splash screen with Shoppix / from A abhi branding
- Red, white and charcoal theme
- Home feed with product Story circles
- Product post cards with seller, location, price and Buy Now
- Bottom navigation: Home, Explore, Post, Messages, Profile
- Demo interactions (snackbars and local like state)

## Not connected yet
This is not a production marketplace yet. Authentication, cloud database, image/video uploads, real Stories/Reels, chat, checkout, payments, shipping, moderation, seller verification and admin tools still need backend implementation and testing.

## Run locally
1. Install Flutter SDK and Android Studio.
2. In this folder run: `flutter pub get`
3. Connect an Android phone with USB debugging enabled, or start an emulator.
4. Run: `flutter run`

To create an Android APK after setup: `flutter build apk --release`

## Before public launch
Configure Firebase (or another backend), payment providers by country, seller policies, privacy policy, terms, shipping integrations, content reporting/moderation, and security rules. Test all payment and order flows before accepting real orders.